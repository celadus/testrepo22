# API
This folder contains the content of your API definition.
Name: API cihat
URL Fragment: kzwrm
Comments: An empty API ready for adding JavaScript functions, JavaScript resources, custom endpoints and data source connections.  

For example, try creating a new function.
