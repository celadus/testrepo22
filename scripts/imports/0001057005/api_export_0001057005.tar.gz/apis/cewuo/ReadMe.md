# API
This folder contains the content of your API definition.
Name: sakila-cewuo
URL Fragment: cewuo
Comments: Insert comments here
