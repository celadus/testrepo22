# API
This folder contains the content of your API definition.
Name: sakila-ksdxc
URL Fragment: ksdxc
Comments: Insert comments here
