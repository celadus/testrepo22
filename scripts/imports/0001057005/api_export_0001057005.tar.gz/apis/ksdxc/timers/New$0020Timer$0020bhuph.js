// Timer code goes here
log.debug("My timer has executed!");
