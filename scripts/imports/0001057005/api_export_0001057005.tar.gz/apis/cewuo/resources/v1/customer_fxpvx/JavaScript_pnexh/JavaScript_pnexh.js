var result = {
    result: "Hello, world!",
    String: "hpsqpxtubj",
    Number: 251.15347561247626,
    "Null value": null
};
return result;
