# CONNECTIONS
This folder contains definitions for connections.
