# API
This folder contains the content of your API definition.
Name: sakila
URL Fragment: etwxw
Comments: Insert comments here
