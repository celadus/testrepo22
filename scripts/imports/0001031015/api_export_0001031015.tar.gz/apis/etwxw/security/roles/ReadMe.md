# ROLES
This contains Roles defined for the project.
Roles define which server features are available and what the permissions
on each feature is enabled.
